from employee import Manager, Worker

# Add a new employee
def add_employee(employees):
    emp_type = input("Enter employee type (Manager/Worker): ").strip().lower()
    name = input("Enter name: ")
    age = int(input("Enter age: "))
    salary = float(input("Enter salary: "))

    if emp_type == "manager":
        department = input("Enter department: ")
        employees.append(Manager(name, age, salary, department))
    elif emp_type == "worker":
        hours_worked = int(input("Enter hours worked: "))
        employees.append(Worker(name, age, salary, hours_worked))
    else:
        print("Invalid employee type.")

# Display all employees
def display_employees(employees):
    for emp in employees:
        print(f"Name: {emp.get_name()}, Age: {emp.get_age()}, Salary: {emp.get_salary()}", end='')
        if isinstance(emp, Manager):
            print(f", Department: {emp.get_department()}")
        elif isinstance(emp, Worker):
            print(f", Hours Worked: {emp.get_hours_worked()}")

# Update an employee
def update_employee(employees):
    name = input("Enter the name of the employee to update: ")
    for emp in employees:
        if emp.get_name() == name:
            emp.set_age(int(input("Enter new age: ")))
            emp.set_salary(float(input("Enter new salary: ")))
            if isinstance(emp, Manager):
                emp.set_department(input("Enter new department: "))
            elif isinstance(emp, Worker):
                emp.set_hours_worked(int(input("Enter new hours worked: ")))
            print("Employee updated successfully.")
            return
    print("Employee not found.")

# Delete an employee
def delete_employee(employees):
    name = input("Enter the name of the employee to delete: ")
    for emp in employees:
        if emp.get_name() == name:
            employees.remove(emp)
            print("Employee deleted successfully.")
            return
    print("Employee not found.")
