from file_handler import load_employees_from_csv, save_employees_to_csv
from operations import add_employee, display_employees, update_employee, delete_employee

def menu():
    filename = "employees.csv"
    employees = load_employees_from_csv(filename)

    while True:
        print("\nEmployee Management System")
        print("1. Add Employee")
        print("2. Display Employees")
        print("3. Update Employee")
        print("4. Delete Employee")
        print("5. Save and Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            add_employee(employees)
        elif choice == "2":
            display_employees(employees)
        elif choice == "3":
            update_employee(employees)
        elif choice == "4":
            delete_employee(employees)
        elif choice == "5":
            save_employees_to_csv(filename, employees)
            print("Changes saved. Exiting.")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    menu()
