import csv
from employee import Manager, Worker

# Save employees to a CSV file
def save_employees_to_csv(filename, employees):
    with open(filename, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["Name", "Age", "Salary", "Department", "Hours Worked"])
        for emp in employees:
            if isinstance(emp, Manager):
                writer.writerow([emp.get_name(), emp.get_age(), emp.get_salary(), emp.get_department(), ""])
            elif isinstance(emp, Worker):
                writer.writerow([emp.get_name(), emp.get_age(), emp.get_salary(), "", emp.get_hours_worked()])

# Load employees from a CSV file
def load_employees_from_csv(filename):
    employees = []
    try:
        with open(filename, 'r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                if row["Department"]:
                    employees.append(Manager(row["Name"], int(row["Age"]), float(row["Salary"]), row["Department"]))
                elif row["Hours Worked"]:
                    employees.append(Worker(row["Name"], int(row["Age"]), float(row["Salary"]), int(row["Hours Worked"])))
    except FileNotFoundError:
        print("File not found. Starting with an empty list.")
    return employees
