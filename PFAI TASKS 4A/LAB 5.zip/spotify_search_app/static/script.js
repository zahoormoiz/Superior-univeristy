document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const resultsContainer = document.getElementById('results-container');
    const loadingSpinner = document.getElementById('loading-spinner');
    const errorMessage = document.getElementById('error-message');
    const errorText = document.getElementById('error-text');

    function performSearch() {
        const query = searchInput.value.trim();
        if (!query) return;

        // UI Reset
        resultsContainer.innerHTML = '';
        errorMessage.classList.add('hidden');
        loadingSpinner.classList.remove('hidden');

        fetch(`/search?q=${encodeURIComponent(query)}`)
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                loadingSpinner.classList.add('hidden');

                if (data.results && data.results.length > 0) {
                    displayResults(data.results);
                } else {
                    showError('No results found. Try another query.');
                }
            })
            .catch(error => {
                loadingSpinner.classList.add('hidden');
                showError('Failed to fetch results. Please try again.');
                console.error('Error:', error);
            });
    }

    function displayResults(results) {
        results.forEach((track, index) => {
            const card = document.createElement('div');
            card.className = 'card';
            card.style.animationDelay = `${index * 0.05}s`;

            // Format year
            const year = track.release_date ? track.release_date.substring(0, 4) : '';

            // High-res artwork if available (iTunes gives 100x100, we can try to get bigger by replacing URL)
            const highResArtwork = track.artwork_url ? track.artwork_url.replace('100x100bb', '600x600bb') : 'https://via.placeholder.com/600?text=No+Art';

            card.innerHTML = `
                <img src="${highResArtwork}" alt="${track.song_name}" loading="lazy">
                <h3>${track.song_name}</h3>
                <p>${track.artist_name}</p>
                <p>${track.album_name}</p>
                ${year ? `<p class="release-year">${year}</p>` : ''}
            `;

            resultsContainer.appendChild(card);
        });
    }

    function showError(message) {
        errorText.textContent = message;
        errorMessage.classList.remove('hidden');
    }

    // Event Listeners
    searchBtn.addEventListener('click', performSearch);

    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') performSearch();
    });
});
