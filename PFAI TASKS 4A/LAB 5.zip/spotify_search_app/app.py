from flask import Flask, request, jsonify, render_template
import requests

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/search', methods=['GET'])
def search_music():
    query = request.args.get('q')
    if not query:
        return jsonify({'error': 'Missing query parameter "q"'}), 400

    # iTunes Search API endpoint
    url = f'https://itunes.apple.com/search?term={query}&media=music&entity=song'
    
    try:
        response = requests.get(url)
        response.raise_for_status()
        data = response.json()
        
        results = []
        for item in data.get('results', []):
            results.append({
                'song_name': item.get('trackName'),
                'artist_name': item.get('artistName'),
                'album_name': item.get('collectionName'),
                'artwork_url': item.get('artworkUrl100'),
                'preview_url': item.get('previewUrl'),
                'release_date': item.get('releaseDate')
            })
            
        return jsonify({'count': len(results), 'results': results})
        
    except requests.exceptions.RequestException as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
