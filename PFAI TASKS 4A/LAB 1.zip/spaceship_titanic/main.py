import os
import sys
from src.data_loader import load_data
from src.preprocessing import preprocess_data
from src.train import train_model, predict_and_save

def main():
    # Define paths
    base_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = os.path.join(base_dir, 'data')
    
    # Check if data exists
    try:
        train_df, test_df = load_data(data_dir)
    except FileNotFoundError as e:
        print(e)
        print("Please place 'train.csv' and 'test.csv' in the 'data' directory.")
        sys.exit(1)
        
    # Preprocess
    print("Preprocessing data...")
    X, y, X_test, test_ids = preprocess_data(train_df, test_df)
    
    # Train
    model = train_model(X, y)
    
    # Predict
    predict_and_save(model, X_test, test_ids, output_path=os.path.join(base_dir, 'submission.csv'))
    
if __name__ == "__main__":
    main()
