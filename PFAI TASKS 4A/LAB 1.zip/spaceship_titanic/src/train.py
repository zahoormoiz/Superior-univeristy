from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score
import pandas as pd

def train_model(X, y):
    """
    Trains a Random Forest model.
    
    Args:
        X (pd.DataFrame): Features.
        y (pd.Series): Target.
        
    Returns:
        model: Trained model.
    """
    print("Training Random Forest model...")
    model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    
    # Simple cross-validation
    scores = cross_val_score(model, X, y, cv=5, scoring='accuracy')
    print(f"Cross-validation accuracy: {scores.mean():.4f} (+/- {scores.std() * 2:.4f})")
    
    model.fit(X, y)
    return model

def predict_and_save(model, X_test, test_ids, output_path='submission.csv'):
    """
    Generates predictions and saves submission file.
    
    Args:
        model: Trained model.
        X_test (pd.DataFrame): Test features.
        test_ids (pd.Series): Test PassengerIds.
        output_path (str): Path to save submission.
    """
    predictions = model.predict(X_test)
    submission = pd.DataFrame({
        'PassengerId': test_ids,
        'Transported': predictions.astype(bool)
    })
    
    submission.to_csv(output_path, index=False)
    print(f"Submission saved to {output_path}")
