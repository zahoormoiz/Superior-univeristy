import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import LabelEncoder

def preprocess_data(train_df, test_df):
    """
    Preprocesses the data: handling missing values, feature engineering, and encoding.
    
    Args:
        train_df (pd.DataFrame): Training data.
        test_df (pd.DataFrame): Test data.
        
    Returns:
        tuple: (X, y, X_test, test_ids)
    """
    # Combine for consistent preprocessing
    train_len = len(train_df)
    test_ids = test_df['PassengerId']
    y = train_df['Transported'].astype(int) if 'Transported' in train_df.columns else None
    
    df = pd.concat([train_df.drop('Transported', axis=1, errors='ignore'), test_df], axis=0)
    
    # Feature Engineering: Cabin
    # Cabin - The cabin number where the passenger is staying. Takes the form deck/num/side, where side can be either P for Port or S for Starboard.
    df[['Deck', 'Num', 'Side']] = df['Cabin'].str.split('/', expand=True)
    
    # Feature Engineering: Total Spend
    luxury_amenities = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
    df[luxury_amenities] = df[luxury_amenities].fillna(0)
    df['TotalSpend'] = df[luxury_amenities].sum(axis=1)
    
    # Feature Engineering: Group size from PassengerId gggg_pp
    df['Group'] = df['PassengerId'].apply(lambda x: x.split('_')[0])
    df['GroupSize'] = df.groupby('Group')['Group'].transform('count')
    
    # Drop high cardinality or unused columns
    cols_to_drop = ['PassengerId', 'Name', 'Cabin', 'Group'] 
    df = df.drop(columns=cols_to_drop)
    
    # Impute missing values
    # Categorical: Mode
    cat_cols = df.select_dtypes(include=['object']).columns
    cat_imputer = SimpleImputer(strategy='most_frequent')
    df[cat_cols] = cat_imputer.fit_transform(df[cat_cols])
    
    # Numerical: Median (already filled amenities with 0, but for others like Age)
    num_cols = df.select_dtypes(include=['number']).columns
    num_imputer = SimpleImputer(strategy='median')
    df[num_cols] = num_imputer.fit_transform(df[num_cols])
    
    # Encoding
    # One-hot encoding for low cardinality
    # Label encoding for Deck/Side if needed, but let's use One-Hot for everything small
    df = pd.get_dummies(df, columns=['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'Deck', 'Side'], drop_first=True)
    
    # Split back
    X = df.iloc[:train_len]
    X_test = df.iloc[train_len:]
    
    return X, y, X_test, test_ids
