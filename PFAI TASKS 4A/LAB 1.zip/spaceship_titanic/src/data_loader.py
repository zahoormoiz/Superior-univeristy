import pandas as pd
import os

def load_data(data_dir):
    """
    Loads train and test datasets from the specified directory.
    
    Args:
        data_dir (str): Path to the directory containing 'train.csv' and 'test.csv'.
        
    Returns:
        tuple: (train_df, test_df) if files exist.
        
    Raises:
        FileNotFoundError: If files are missing.
    """
    train_path = os.path.join(data_dir, 'train.csv')
    test_path = os.path.join(data_dir, 'test.csv')
    
    if not os.path.exists(train_path):
        raise FileNotFoundError(f"Train file not found at {train_path}. Please download it from Kaggle.")
    
    if not os.path.exists(test_path):
        raise FileNotFoundError(f"Test file not found at {test_path}. Please download it from Kaggle.")
        
    train_df = pd.read_csv(train_path)
    test_df = pd.read_csv(test_path)
    
    print(f"Loaded train shape: {train_df.shape}")
    print(f"Loaded test shape: {test_df.shape}")
    
    return train_df, test_df
