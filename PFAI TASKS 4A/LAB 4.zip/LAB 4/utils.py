import cv2
import dlib
import numpy as np
import os
import math

# Initialize dlib's face detector (HOG-based) and then create
# the facial landmark predictor
detector = dlib.get_frontal_face_detector()

# Path to the shape predictor model
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'models', 'shape_predictor_68_face_landmarks.dat')

predictor = None
if os.path.exists(MODEL_PATH):
    predictor = dlib.shape_predictor(MODEL_PATH)
else:
    print(f"WARNING: Model file not found at {MODEL_PATH}. Face profiling will not work correctly.")

def get_landmarks(image):
    """
    Detects face and returns 68 landmarks.
    """
    if predictor is None:
        return None, "Model file missing"

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    rects = detector(gray, 1)

    if len(rects) == 0:
        return None, "No face detected"

    # Process only the first face found
    shape = predictor(gray, rects[0])
    coords = np.zeros((68, 2), dtype="int")

    for i in range(0, 68):
        coords[i] = (shape.part(i).x, shape.part(i).y)

    return coords, None

def calculate_distance(p1, p2):
    return math.sqrt((p1[0] - p2[0])**2 + (p1[1] - p2[1])**2)

def analyze_face(image_path):
    """
    Analyzes the face and returns profile data.
    """
    image = cv2.imread(image_path)
    if image is None:
        return None, "Could not read image"

    landmarks, error = get_landmarks(image)
    if error:
        return None, error

    # Feature Measurements (Indices based on 68-point model)
    # Jaw: 0-16
    # Right Eyebrow: 17-21
    # Left Eyebrow: 22-26
    # Nose: 27-35
    # Right Eye: 36-41
    # Left Eye: 42-47
    # Mouth: 48-67

    # Calculate some metrics
    jaw_width = calculate_distance(landmarks[0], landmarks[16])
    face_height = calculate_distance(landmarks[8], landmarks[27]) # Chin to Nose bridge (approx)
    
    eye_distance = calculate_distance(landmarks[36], landmarks[45]) # Outer corners
    
    # Ratios
    face_ratio = face_height / jaw_width if jaw_width > 0 else 0
    eye_spacing_ratio = eye_distance / jaw_width if jaw_width > 0 else 0

    # Personality Profiling (Pseudo-science/Entertainment)
    profile = {}
    
    if face_ratio > 0.8:
        profile['Face Shape'] = "Oblong/Oval"
        profile['Trait 1'] = "Analytical & Diplomatic"
    else:
        profile['Face Shape'] = "Square/Round"
        profile['Trait 1'] = "Practical & Assertive"

    if eye_spacing_ratio > 0.45:
        profile['Eye Spacing'] = "Wide"
        profile['Trait 2'] = "Tolerant & Broad-minded"
    else:
        profile['Eye Spacing'] = "Narrow"
        profile['Trait 2'] = "Focused & Detail-oriented"

    # Draw landmarks on image for visualization
    for (x, y) in landmarks:
        cv2.circle(image, (x, y), 2, (0, 255, 0), -1)
    
    # Save processed image
    processed_filename = "processed_" + os.path.basename(image_path)
    processed_path = os.path.join(os.path.dirname(image_path), processed_filename)
    cv2.imwrite(processed_path, image)

    return {
        'measurements': {
            'Jaw Width': f"{jaw_width:.2f}px",
            'Face Height': f"{face_height:.2f}px",
            'Face Ratio': f"{face_ratio:.2f}"
        },
        'profile': profile,
        'processed_image': processed_filename
    }, None
