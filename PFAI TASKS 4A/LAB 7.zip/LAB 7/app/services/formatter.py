def format_book_data(raw_data):
    """
    Formats the raw data from Google Books API into a clean list of books.
    
    Args:
        raw_data (dict): The raw JSON response from the API.
        
    Returns:
        list: A list of dictionaries containing cleaned book info.
    """
    books = []
    
    if not raw_data or "items" not in raw_data:
        return books
        
    for item in raw_data["items"]:
        volume_info = item.get("volumeInfo", {})
        
        # safely extract fields
        book = {
            "title": volume_info.get("title", "Unknown Title"),
            "authors": volume_info.get("authors", ["Unknown Author"]),
            "published_year": volume_info.get("publishedDate", "Unknown Date")[:4] if volume_info.get("publishedDate") else "Unknown Year",
            "thumbnail": volume_info.get("imageLinks", {}).get("thumbnail", None),
            "description": volume_info.get("description", "No description available.")
        }
        
        books.append(book)
        
    return books
