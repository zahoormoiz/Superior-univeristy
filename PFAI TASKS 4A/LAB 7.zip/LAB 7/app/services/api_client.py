import requests

GOOGLE_BOOKS_API_URL = "https://www.googleapis.com/books/v1/volumes"

def fetch_books(query):
    """
    Fetches books from the Google Books API based on the search query.
    
    Args:
        query (str): The search term.
        
    Returns:
        dict: The JSON response from the API.
        
    Raises:
        requests.RequestException: If the API request fails.
    """
    params = {
        "q": query,
        "maxResults": 20  # Fetch a reasonable number of results
    }
    
    try:
        response = requests.get(GOOGLE_BOOKS_API_URL, params=params)
        response.raise_for_status()
        return response.json()
    except requests.RequestException as e:
        # Log error here if logging was set up
        print(f"Error fetching data from Google Books API: {e}")
        return None
