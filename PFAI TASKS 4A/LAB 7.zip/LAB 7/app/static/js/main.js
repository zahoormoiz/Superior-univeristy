document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.getElementById('search-form');
    const searchInput = document.getElementById('search-input');
    const resultsSection = document.getElementById('results-section');
    const resultsGrid = document.getElementById('results-grid');
    const loader = document.getElementById('loader');
    const historyToggle = document.getElementById('history-toggle');
    const historySidebar = document.getElementById('history-sidebar');
    const closeHistory = document.getElementById('close-history');
    const historyList = document.getElementById('history-list');

    // --- Search Functionality ---

    searchForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const query = searchInput.value.trim();

        if (!query) return;

        showLoader();
        resultsSection.classList.remove('hidden');
        resultsGrid.innerHTML = ''; // Clear previous results

        try {
            const response = await fetch(`/search?query=${encodeURIComponent(query)}`);
            const data = await response.json();

            if (response.ok) {
                renderResults(data);
            } else {
                showToast(data.error || 'An error occurred while searching.', 'error');
            }
        } catch (error) {
            console.error('Network error:', error);
            showToast('Network error. Please try again.', 'error');
        } finally {
            hideLoader();
            // Refresh history
            fetchHistory();
        }
    });

    function renderResults(books) {
        if (!books || books.length === 0) {
            resultsGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: var(--text-muted);">No books found.</p>';
            return;
        }

        books.forEach(book => {
            const card = document.createElement('div');
            card.className = 'book-card glass-panel';

            const thumbnail = book.thumbnail
                ? `<img src="${book.thumbnail}" alt="${book.title}" class="card-image">`
                : `<div class="card-image"><div class="thumb-placeholder">📕</div></div>`;

            const authors = book.authors && book.authors.length > 0
                ? book.authors.join(', ')
                : 'Unknown Author';

            const rating = book.average_rating
                ? `<span class="rating">★ ${book.average_rating}</span>`
                : '<span class="rating" style="color: var(--text-muted)">-</span>';

            card.innerHTML = `
                ${thumbnail}
                <div class="card-content">
                    <div class="book-title" title="${book.title}">${truncate(book.title, 50)}</div>
                    <div class="book-authors">${truncate(authors, 35)}</div>
                    <div class="book-meta">
                        ${rating}
                        <span>${book.published_date || 'N/A'}</span>
                    </div>
                </div>
            `;

            resultsGrid.appendChild(card);
        });
    }

    function truncate(str, n) {
        return (str.length > n) ? str.substr(0, n - 1) + '&hellip;' : str;
    }

    function showLoader() {
        loader.classList.remove('hidden');
    }

    function hideLoader() {
        loader.classList.add('hidden');
    }

    // --- History Functionality ---

    historyToggle.addEventListener('click', () => {
        historySidebar.classList.add('open');
        fetchHistory();
    });

    closeHistory.addEventListener('click', () => {
        historySidebar.classList.remove('open');
    });

    // Close sidebar when clicking outside
    document.addEventListener('click', (e) => {
        if (!historySidebar.contains(e.target) && !historyToggle.contains(e.target) && historySidebar.classList.contains('open')) {
            historySidebar.classList.remove('open');
        }
    });

    async function fetchHistory() {
        try {
            const response = await fetch('/history');
            const data = await response.json();

            if (data.history) {
                renderHistory(data.history);
            }
        } catch (error) {
            console.error('Failed to fetch history:', error);
        }
    }

    function renderHistory(historyItems) {
        historyList.innerHTML = '';
        if (historyItems.length === 0) {
            historyList.innerHTML = '<li style="color: var(--text-muted); padding: 1rem;">No recent details.</li>';
            return;
        }

        historyItems.forEach(item => {
            const li = document.createElement('li');
            li.className = 'history-item';
            li.textContent = item;
            li.addEventListener('click', () => {
                searchInput.value = item;
                searchForm.dispatchEvent(new Event('submit'));
                historySidebar.classList.remove('open');
            });
            historyList.appendChild(li);
        });
    }

    // --- Utilities ---

    function showToast(message, type = 'info') {
        const toastContainer = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = 'toast';
        toast.textContent = message;

        if (type === 'error') {
            toast.style.borderColor = '#ff4b4b';
        }

        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateY(20px)';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
});
