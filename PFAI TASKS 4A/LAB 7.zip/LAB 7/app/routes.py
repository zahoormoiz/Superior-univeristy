from flask import Blueprint, jsonify, request, render_template
from app.services.api_client import fetch_books
from app.services.formatter import format_book_data

main_bp = Blueprint('main', __name__)

# In-memory storage for search history (last 10 queries)
search_history = []

@main_bp.route('/', methods=['GET'])
def index():
    """
    Serve the main application page.
    """
    return render_template('index.html')

@main_bp.route('/search', methods=['GET'])
def search():
    """
    Search for books by title, author, or ISBN.
    """
    query = request.args.get('query')
    
    if not query:
        return jsonify({"error": "Missing query parameter"}), 400
        
    # Update history
    search_history.insert(0, query)
    if len(search_history) > 10:
        search_history.pop()
        
    # Fetch data
    raw_data = fetch_books(query)
    
    if raw_data is None:
        return jsonify({"error": "Failed to fetch data from external API"}), 502
        
    # Format data
    formatted_books = format_book_data(raw_data)
    
    return jsonify(formatted_books)

@main_bp.route('/history', methods=['GET'])
def history():
    """
    Return the last 10 search queries.
    """
    return jsonify({"history": search_history})
