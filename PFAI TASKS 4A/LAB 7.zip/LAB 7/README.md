# lbooks enginta

A modular Flask backend API for searching books using the Google Books API.

## Requirements

- Python 3.8+
- Flask
- Requests

## Installation

1. Navigate to the project directory:
   ```bash
   cd lbooks_enginta
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. Run the server:
   ```bash
   python run.py
   ```

2. The API will be available at `http://localhost:5000`.

## Endpoints

### 1. Health Check
- **URL**: `/`
- **Method**: `GET`
- **Response**:
  ```json
  {
      "app": "antigravity-books",
      "status": "running"
  }
  ```

### 2. Search Books
- **URL**: `/search`
- **Method**: `GET`
- **Query Params**: `query` (required)
- **Example**: `/search?query=harry+potter`
- **Response**: List of books with title, authors, year, thumbnail, description.

### 3. Search History
- **URL**: `/history`
- **Method**: `GET`
- **Response**: List of the last 10 search queries.
