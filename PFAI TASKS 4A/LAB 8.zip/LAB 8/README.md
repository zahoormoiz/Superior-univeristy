# AI Lab: Tokenization Implementation

This project contains Python scripts to demonstrate text tokenization (word-level and sentence-level) using two popular NLP libraries: **NLTK** and **spaCy**.

## Prerequisites

You need Python installed. It is recommended to use a virtual environment.

### Installation

1.  Install the required libraries:
    ```bash
    pip install -r requirements.txt
    ```

2.  **For spaCy**, you need to download the English language model:
    ```bash
    python -m spacy download en_core_web_sm
    ```

## Running the Scripts

### NLTK Solution
Run the NLTK implementation:
```bash
python nltk_solution.py
```
*Note: The script will attempt to download the `punkt` tokenizer data if it's missing.*

### spaCy Solution
Run the spaCy implementation:
```bash
python spacy_solution.py
```

## Expected Output

Both scripts differ slightly in output formatting but will essentially produce:

**Sentences:**
1. Natural Language Processing is interesting.
2. Tokenization is the first step.

**Words:**
['Natural', 'Language', 'Processing', 'is', 'interesting', '.', 'Tokenization', 'is', 'the', 'first', 'step', '.']
