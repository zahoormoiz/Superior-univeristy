import spacy

def main():
    # Load the English language model
    # Note: Run 'python -m spacy download en_core_web_sm' if not installed
    try:
        nlp = spacy.load("en_core_web_sm")
    except OSError:
        print("Error: 'en_core_web_sm' model not found.")
        print("Please run: python -m spacy download en_core_web_sm")
        return

    # Sample text
    text = "Natural Language Processing is interesting. Tokenization is the first step."
    print(f"Original Text:\n{text}\n")

    # Process the text using the nlp object
    doc = nlp(text)

    # Sentence Tokenization
    print("Sentence Tokenization Result:")
    for i, sent in enumerate(doc.sents, 1):
        print(f"{i}: {sent.text}")
    print()

    # Word Tokenization
    print("Word Tokenization Result:")
    # Using list comprehension to show simply the text of each token
    tokens = [token.text for token in doc]
    print(tokens)

if __name__ == "__main__":
    main()
