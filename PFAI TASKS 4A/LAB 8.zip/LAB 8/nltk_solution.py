import nltk

def main():
    # Ensure necessary NLTK data is downloaded
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        print("Downloading 'punkt' tokenizer models...")
        nltk.download('punkt')
        nltk.download('punkt_tab')

    # Sample text
    text = "Natural Language Processing is interesting. Tokenization is the first step."
    print(f"Original Text:\n{text}\n")

    # Sentence Tokenization
    sentences = nltk.sent_tokenize(text)
    print("Sentence Tokenization Result:")
    for i, sent in enumerate(sentences, 1):
        print(f"{i}: {sent}")
    print()

    # Word Tokenization
    words = nltk.word_tokenize(text)
    print("Word Tokenization Result:")
    print(words)

if __name__ == "__main__":
    main()
