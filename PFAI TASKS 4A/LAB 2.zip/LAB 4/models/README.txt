This project requires the dlib face landmark predictor model.

1. Download the file from: http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2
2. Extract the .bz2 archive.
3. Place the `shape_predictor_68_face_landmarks.dat` file in this directory (`face_profiling/models/`).
