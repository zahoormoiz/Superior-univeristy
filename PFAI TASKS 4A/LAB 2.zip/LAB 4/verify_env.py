import sys
import os

def check_env():
    print("Checking environment for Face Profiling App...")
    
    # Check Flask
    try:
        import flask
        print(f"[OK] Flask is installed (version {flask.__version__})")
    except ImportError:
        print("[FAIL] Flask is NOT installed.")

    # Check OpenCV
    try:
        import cv2
        print(f"[OK] OpenCV is installed (version {cv2.__version__})")
    except ImportError:
        print("[FAIL] OpenCV is NOT installed.")

    # Check dlib
    try:
        import dlib
        print(f"[OK] dlib is installed (version {dlib.__version__})")
    except ImportError:
        print("[FAIL] dlib is NOT installed.")

    # Check Model File
    model_path = os.path.join('face_profiling', 'models', 'shape_predictor_68_face_landmarks.dat')
    if os.path.exists(model_path):
        print(f"[OK] Model file found at {model_path}")
    else:
        print(f"[WARNING] Model file NOT found at {model_path}. Please download it.")

if __name__ == "__main__":
    check_env()
