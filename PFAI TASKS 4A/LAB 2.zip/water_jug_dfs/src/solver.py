class WaterJugSolver:
    def __init__(self, capacity_x, capacity_y, target):
        self.capacity_x = capacity_x
        self.capacity_y = capacity_y
        self.target = target
        self.visited = set()
        self.path = []

    def solve(self):
        """
        Solves the Water Jug problem using DFS.
        Returns a list of steps (rules applied) if a solution is found, else None.
        """
        # Stack stores (state, path_so_far)
        # State is (jug_x, jug_y)
        initial_state = (0, 0)
        stack = [(initial_state, [])]
        
        while stack:
            (current_x, current_y), path = stack.pop()
            
            if (current_x, current_y) in self.visited:
                continue
            
            self.visited.add((current_x, current_y))
            
            # Check if target is reached
            if current_x == self.target or current_y == self.target:
                return path
            
            # Generate next states
            # Rule 1: Fill Jug X
            if current_x < self.capacity_x:
                new_state = (self.capacity_x, current_y)
                if new_state not in self.visited:
                    stack.append((new_state, path + [f"Fill Jug X ({self.capacity_x}L)"]))

            # Rule 2: Fill Jug Y
            if current_y < self.capacity_y:
                new_state = (current_x, self.capacity_y)
                if new_state not in self.visited:
                    stack.append((new_state, path + [f"Fill Jug Y ({self.capacity_y}L)"]))

            # Rule 3: Empty Jug X
            if current_x > 0:
                new_state = (0, current_y)
                if new_state not in self.visited:
                    stack.append((new_state, path + ["Empty Jug X"]))

            # Rule 4: Empty Jug Y
            if current_y > 0:
                new_state = (current_x, 0)
                if new_state not in self.visited:
                    stack.append((new_state, path + ["Empty Jug Y"]))

            # Rule 5: Pour X -> Y
            if current_x > 0 and current_y < self.capacity_y:
                amount_to_pour = min(current_x, self.capacity_y - current_y)
                new_state = (current_x - amount_to_pour, current_y + amount_to_pour)
                if new_state not in self.visited:
                    stack.append((new_state, path + ["Pour Jug X -> Jug Y"]))

            # Rule 6: Pour Y -> X
            if current_y > 0 and current_x < self.capacity_x:
                amount_to_pour = min(current_y, self.capacity_x - current_x)
                new_state = (current_x + amount_to_pour, current_y - amount_to_pour)
                if new_state not in self.visited:
                    stack.append((new_state, path + ["Pour Jug Y -> Jug X"]))
                    
        return None
