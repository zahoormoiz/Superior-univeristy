import sys
from src.solver import WaterJugSolver

def main():
    # Default values
    cap_x = 4
    cap_y = 3
    target = 2
    
    # Allow command line args override
    if len(sys.argv) == 4:
        try:
            cap_x = int(sys.argv[1])
            cap_y = int(sys.argv[2])
            target = int(sys.argv[3])
        except ValueError:
            print("Invalid arguments. Usage: python main.py <cap_x> <cap_y> <target>")
            return

    print(f"Solving Water Jug Problem: Jug X={cap_x}L, Jug Y={cap_y}L, Target={target}L")
    
    solver = WaterJugSolver(cap_x, cap_y, target)
    steps = solver.solve()
    
    if steps:
        print("\nSolution Found:")
        for i, step in enumerate(steps, 1):
            print(f"Step {i}: {step}")
    else:
        print("\nNo solution found.")

if __name__ == "__main__":
    main()
