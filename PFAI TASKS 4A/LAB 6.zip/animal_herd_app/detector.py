from ultralytics import YOLO
import cv2
import os

# Load model (download on first run)
model = YOLO('yolov8n.pt')

# COCO classes for common herd animals
# 16: dog, 17: horse, 18: sheep, 19: cow, 20: elephant, 21: bear, 22: zebra, 23: giraffe
HERD_CLASSES = [16, 17, 18, 19, 20, 21, 22, 23]

def detect_animals(source_path, output_path):
    """
    Detects animals in the source image/video.
    Saves processed media to output_path.
    Returns detection stats.
    """
    results = model(source_path, classes=HERD_CLASSES)
    
    # Process the first result (single image for now)
    result = results[0]
    
    # Save plotted image
    im_array = result.plot()  # plot a BGR numpy array of predictions
    cv2.imwrite(output_path, im_array)
    
    # Count detections
    counts = {}
    boxes = result.boxes
    for box in boxes:
        cls = int(box.cls[0])
        name = model.names[cls]
        counts[name] = counts.get(name, 0) + 1
        
    return counts
