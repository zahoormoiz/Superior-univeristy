import os
from flask import Flask, render_template, request, jsonify, send_from_directory
from detector import detect_animals
import time

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['STATIC_FOLDER'] = 'static'

# Ensure directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['STATIC_FOLDER'], exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file:
        filename = f"{int(time.time())}_{file.filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        
        # Process image
        output_filename = f"processed_{filename}"
        output_path = os.path.join(app.config['STATIC_FOLDER'], output_filename)
        
        counts = detect_animals(filepath, output_path)
        
        # Determine if herd (threshold > 2 animals)
        total_animals = sum(counts.values())
        is_herd = total_animals >= 3
        
        return jsonify({
            'success': True,
            'image_url': f"/static/{output_filename}",
            'counts': counts,
            'is_herd': is_herd,
            'total': total_animals
        })

if __name__ == '__main__':
    # Using port 5001 to avoid conflict with previous app
    app.run(debug=True, port=5001)
