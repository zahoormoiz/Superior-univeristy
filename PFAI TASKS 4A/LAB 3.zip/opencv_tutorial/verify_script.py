import cv2
import numpy as np
import os

def verify_opencv():
    print("Verifying OpenCV...")
    
    # 1. Read Image
    image_path = os.path.join('opencv_tutorial', 'images', 'sample.jpg')
    if not os.path.exists(image_path):
        print(f"Error: {image_path} not found.")
        return
        
    img = cv2.imread(image_path)
    if img is None:
        print("Error: Failed to read image.")
        return
    print(f"Image read successfully. Shape: {img.shape}")
    
    # 2. Resize
    resized = cv2.resize(img, (200, 200))
    print(f"Resized shape: {resized.shape}")
    
    # 3. Rotate
    (h, w) = img.shape[:2]
    center = (w // 2, h // 2)
    M = cv2.getRotationMatrix2D(center, 45, 1.0)
    rotated = cv2.warpAffine(img, M, (w, h))
    print("Rotation successful.")
    
    # 4. Grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    print(f"Grayscale shape: {gray.shape}")
    
    # 5. Blur
    blurred = cv2.GaussianBlur(img, (15, 15), 0)
    print("Blur successful.")
    
    # 6. Canny
    edges = cv2.Canny(img, 100, 200)
    print("Edge detection successful.")
    
    # 7. Drawing
    canvas = np.zeros((300, 300, 3), dtype="uint8")
    cv2.line(canvas, (0, 0), (300, 300), (0, 255, 0), 3)
    print("Drawing successful.")
    
    print("All OpenCV verifications passed!")

if __name__ == "__main__":
    verify_opencv()
