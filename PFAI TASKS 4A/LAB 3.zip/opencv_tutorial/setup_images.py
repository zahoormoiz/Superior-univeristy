import cv2
import numpy as np
import os

def create_sample_image():
    # Create a 400x400 black image
    img = np.zeros((400, 400, 3), dtype=np.uint8)
    
    # Draw a blue rectangle
    cv2.rectangle(img, (50, 50), (150, 150), (255, 0, 0), -1)
    
    # Draw a green circle
    cv2.circle(img, (300, 100), 50, (0, 255, 0), -1)
    
    # Draw a red line
    cv2.line(img, (50, 300), (350, 300), (0, 0, 255), 5)
    
    # Save the image
    output_path = os.path.join('opencv_tutorial', 'images', 'sample.jpg')
    cv2.imwrite(output_path, img)
    print(f"Sample image saved to {output_path}")

if __name__ == "__main__":
    create_sample_image()
